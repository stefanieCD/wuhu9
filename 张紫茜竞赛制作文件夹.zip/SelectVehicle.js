document.getElementById('action').addEventListener('click', function () {
    this.style.border = '2px solid blue'; /* 点击后添加蓝色边框 */
  });